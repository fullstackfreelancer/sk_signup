CREATE TABLE fe_users (
    tx_sksignup_key varchar(255) DEFAULT '' NOT NULL,
);
